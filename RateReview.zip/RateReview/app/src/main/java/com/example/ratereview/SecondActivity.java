package com.example.ratereview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class SecondActivity extends AppCompatActivity {
    public Button Nonveg;
    public Button Veg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Nonveg = (Button) findViewById(R.id.button2);
        Nonveg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openactivitynonveg_menu();
            }
        });
        Veg = (Button) findViewById(R.id.button);
        Veg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityveg_menu();
            }
        });

    }

    public void openactivitynonveg_menu() {
        Intent intent1 = new Intent(this, Nonveg_Menu.class);
        startActivity(intent1);
    }

    public void openActivityveg_menu() {
        Intent intent2 = new Intent(this,Veg_Menu.class);
        startActivity(intent2);
    }
}
