package com.example.ratereview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Nonveg_Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nonveg__menu);
    }
}